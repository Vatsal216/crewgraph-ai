"""
Simple 2-Agent Test - Minimal Version
"""

print("🚀 Starting 2-Agent Test...")

try:
    print("📦 Importing libraries...")
    from crewai import Agent, Tool
    print("✅ CrewAI imported")
    
    from crewgraph_ai import CrewGraph
    print("✅ CrewGraph imported")
    
    from crewgraph_ai.memory import DictMemory
    print("✅ DictMemory imported")
    
    print("\n🤖 Creating agents...")
    
    def simple_research(topic):
        return f"Research results for {topic}: Key findings about the topic."
    
    def simple_write(content):
        return f"Article: {content} This is a well-written piece."
    
    # Create agents
    researcher = Agent(
        role='Researcher',
        goal='Research topics',
        backstory='I research things.',
        tools=[Tool(name="research", func=simple_research, description="Research")],
        verbose=False
    )
    
    writer = Agent(
        role='Writer', 
        goal='Write content',
        backstory='I write things.',
        tools=[Tool(name="write", func=simple_write, description="Write")],
        verbose=False
    )
    
    print("✅ Agents created successfully")
    
    # Create workflow
    workflow = CrewGraph("test_workflow")
    workflow.add_agent(researcher, name="researcher")
    workflow.add_agent(writer, name="writer")
    
    print("✅ Workflow created successfully")
    
    # Add tasks
    workflow.add_task(
        name="research_task",
        description="Research AI trends",
        agent="researcher"
    )
    
    workflow.add_task(
        name="write_task", 
        description="Write about the research",
        agent="writer",
        dependencies=["research_task"]
    )
    
    print("✅ Tasks added successfully")
    
    # Execute
    print("\n🏃 Executing workflow...")
    results = workflow.execute({"topic": "AI trends"})
    
    print("✅ Execution completed!")
    print(f"📊 Results: {results}")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()

print("\n🎉 Test completed!")
